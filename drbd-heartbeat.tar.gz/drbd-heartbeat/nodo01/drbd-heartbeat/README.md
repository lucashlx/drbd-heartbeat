# Preparar

Carregar o modulo 

modprobe cn
modprobe drbd

5 – Agora vamos criar os discos virtuais nos dois servidores:
# Para o comando funcinoar o arquivo tem que está correto, se nao vai ficar
# registrnado, config host'r0' not defined in your config (for this host).
# 
# drbdadm create-md r0



Leia mais: https://dudusamuca.webnode.com.br/manuais-linux/debian/drbd/
